
package dibiasesantino.pkg322.rp1;


import java.util.Objects;

public abstract class Presentacion {
    private final String nombre;
    private final String escenario;
    private final TipoEscenario tipoEscenario;

    
    
    public Presentacion(String nombre, String escenario, TipoEscenario tipoEscenario) {
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoEscenario = tipoEscenario;
        
        
    }

    
    public String getNombre() { return nombre; }
    public String getEscenario() { return escenario; }
    public TipoEscenario getTipoEscenario() { return tipoEscenario; }

    
    
    
    @Override
    public String toString() {
    return nombre + " - Escenario: " + escenario + " (" + tipoEscenario + ")";

    
    
    }
    
    

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Presentacion)) return false;
        Presentacion that = (Presentacion) o;
        return nombre.equalsIgnoreCase(that.nombre) &&
               escenario.equalsIgnoreCase(that.escenario);
    
    
    }
        
    
    

    @Override
    public int hashCode() {
        return Objects.hash(
            nombre == null ? null : nombre.toLowerCase(),
            escenario == null ? null : escenario.toLowerCase()
        );
    
    
    }





}