
package dibiasesantino.pkg322.rp1;

public class Main {
    public static void main(String[] args) {
        Recital recital = new Recital();

        try {
            Banda b1 = new Banda(5, "Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR);
            Solista s1 = new Solista("Guitarra", "Maria Sol", "Escenario Secundario", TipoEscenario.INTERIOR);
            DJ d1 = new DJ("Techno", "DJ Thunder", "Escenario Principal", TipoEscenario.EXTERIOR);

            recital.agregarPresentacion(b1);
            recital.agregarPresentacion(s1);
            recital.agregarPresentacion(d1);

            
            Banda b2 = new Banda(6, "Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR);
            try{
                
                recital.agregarPresentacion(b2); 
            
            }catch (PresentacionDuplicada ex) {
               
                System.out.println("Error al agregar duplicado: " + ex.getMessage());
            
            }

          
            recital.mostrarPresentaciones();

            
            recital.tocarEnVivo();   

           
            recital.filtrarPorTipoEscenario(TipoEscenario.EXTERIOR);
            recital.filtrarPorTipoEscenario(TipoEscenario.INTERIOR);

            
            recital.eliminarPresentacionesPorTipo("DJ");
            recital.mostrarPresentaciones();

        } catch (PresentacionDuplicada e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}