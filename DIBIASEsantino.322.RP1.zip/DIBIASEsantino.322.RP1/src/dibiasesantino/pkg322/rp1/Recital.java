
package dibiasesantino.pkg322.rp1;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Recital {
    private List<Presentacion> presentaciones;

    public Recital() {
       
        this.presentaciones = new ArrayList<>();
    
    }

    public void agregarPresentacion(Presentacion p) throws PresentacionDuplicada {
        if (presentaciones.contains(p)) {
            throw new PresentacionDuplicada(
                "Ya existe la presentacion '" + p.getNombre() + "' en el escenario '" + p.getEscenario() + "'."
            
           );
       
        }
        
        
        presentaciones.add(p);
        System.out.println("Presentacion agregada: " + p.getNombre());
    
    
    }

    public void mostrarPresentaciones() {
        System.out.println("\n========== PRESENTACIONES REGISTRADAS ==========");
        if (presentaciones.isEmpty()) {
            System.out.println("No hay presentaciones registradas.");
            return;
        }
        for (Presentacion p : presentaciones) {
            System.out.println(p.toString());
        }
    }

    public void tocarEnVivo() {
        System.out.println("\n========== EJECUTANDO tocarEnVivo() ==========");
        for (Presentacion p : presentaciones) {
            if (p instanceof Tocable) {
                ((Tocable) p).tocarEnVivo();
            
            } else {
                System.out.println("La presentacion " + p.getNombre() + " no puede tocar en vivo.");
            }
       
        }
    
    }

    public void animarPublico() {
        System.out.println("\n========== EJECUTANDO animarPublico() ==========");
        for (Presentacion p : presentaciones) {
            if (p instanceof Animable) {
                ((Animable) p).animarPublico();
            } else {
                System.out.println("La presentacion " + p.getNombre() + " no puede animar al público.");
            
            }
        
        
        
        
    }
    }

    
    
    public List<Presentacion> filtrarPorTipoEscenario(TipoEscenario tipo) {
        System.out.println("\n========== PRESENTACIONES EN ESCENARIO: " + tipo + " ==========");
        List<Presentacion> res = new ArrayList<>();
            
        
        for (Presentacion p : presentaciones) {
            if (p.getTipoEscenario() == tipo) {
                res.add(p);
                System.out.println(p);
            }
        }
        if (res.isEmpty()) {
            System.out.println("No se encontraron presentaciones para el tipo: " + tipo);
        }
        
        return res;
    
    }

    public int eliminarPresentacionesPorTipo(String tipoPresentacion) {
        int count = 0;
        Iterator<Presentacion> it = presentaciones.iterator();
        
        while (it.hasNext()) {
            Presentacion p = it.next();
            String clase = p.getClass().getSimpleName();
            if (clase.equalsIgnoreCase(tipoPresentacion)) {
                it.remove();
                count++;
            }
        
        }
        
        System.out.println("Se eliminaron " + count + " presentaciones de tipo '" + tipoPresentacion + "'.");
        return count;
    
    }



}
