
package dibiasesantino.pkg322.rp1;



public enum TipoEscenario {
    INTERIOR,
    EXTERIOR;
}