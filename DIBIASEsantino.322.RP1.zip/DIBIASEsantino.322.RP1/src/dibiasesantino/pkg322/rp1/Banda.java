
package dibiasesantino.pkg322.rp1;


public class Banda extends Presentacion implements Tocable {
    private final int maxIntegrantes;

    public Banda(int maxIntegrantes, String nombre, String escenario, TipoEscenario tipoEscenario) {
        super(nombre, escenario, tipoEscenario);
        this.maxIntegrantes = maxIntegrantes;
    
    
    }

    public int getMaxIntegrantes(){ return maxIntegrantes; }

    @Override
    public void tocarEnVivo() {
        System.out.println(getNombre() + " esta tocando en vivo en " + getEscenario() + "!!!");
    
    
    }

    @Override
    public String toString() {
        return "Banda: " + super.toString() + ", Max integrantes: " + maxIntegrantes;
    }





}