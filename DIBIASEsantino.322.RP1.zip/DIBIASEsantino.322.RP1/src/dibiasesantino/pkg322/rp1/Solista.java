
package dibiasesantino.pkg322.rp1;



public class Solista extends Presentacion implements Tocable, Animable {
    private String instrumentoPrincipal;

    public Solista(String instrumentoPrincipal, String nombre, String escenario, TipoEscenario tipoEscenario) {
        super(nombre, escenario, tipoEscenario);
        this.instrumentoPrincipal = instrumentoPrincipal;
    }

    public String getInstrumentoPrincipal() { return instrumentoPrincipal;}

    @Override
    public void tocarEnVivo() {
        System.out.println(getNombre() + " (solista, " + instrumentoPrincipal + ") esta tocando en vivo en " + getEscenario() + "!");
    
    }

    @Override
    public void animarPublico() {
        System.out.println(getNombre() + " anima al publico!");
    }

    @Override
    public String toString(){
        return "Solista: " + super.toString() + ", Instrumento: " + instrumentoPrincipal;
    }






}
