
package dibiasesantino.pkg322.rp1;



public interface Animable {
    void animarPublico();




}
