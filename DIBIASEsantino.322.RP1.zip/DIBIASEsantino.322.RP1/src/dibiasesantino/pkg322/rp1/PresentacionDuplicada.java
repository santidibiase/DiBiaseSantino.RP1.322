
package dibiasesantino.pkg322.rp1;



public class PresentacionDuplicada extends Exception {
    public PresentacionDuplicada(String mensaje) {
        super(mensaje);
    }
}