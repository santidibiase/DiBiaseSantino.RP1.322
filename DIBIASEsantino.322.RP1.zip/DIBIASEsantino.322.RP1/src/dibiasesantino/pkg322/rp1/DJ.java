
package dibiasesantino.pkg322.rp1;



public class DJ extends Presentacion implements Animable{
    private String estiloMusical;

    public DJ(String estiloMusical, String nombre, String escenario, TipoEscenario tipoEscenario) {
       super(nombre, escenario, tipoEscenario);
        this.estiloMusical = estiloMusical;
    }

    public String getEstiloMusical() { return estiloMusical; }

    @Override
    public void animarPublico(){
      System.out.println(getNombre() + " (DJ - " + estiloMusical + ") esta animando a la gente con sus tracks!");
    
    
    }

    @Override
    public String toString() {
        return "DJ: " + super.toString() + ", Estilo: " + estiloMusical;
    }

}