package DiB;

import java.util.Objects;

public abstract class Pieza {
    private String nombre;
    private String ubicacionBox;
    private CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacionBox = ubicacionBox;
        this.condicionClimatica = condicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacionBox() {
        return ubicacionBox;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    @Override
    public String toString() {
        return "Pieza:\n" + "nombre: " + nombre + ", ubicacionBox: " + ubicacionBox + ", condicionClimatica: " + condicionClimatica;
    }

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pieza)) return false;
        Pieza other = (Pieza) o;
        if (this.nombre == null || this.ubicacionBox == null || other.nombre == null || other.ubicacionBox == null) {
            return false;
        }
        return this.nombre.equalsIgnoreCase(other.nombre) &&
               this.ubicacionBox.equalsIgnoreCase(other.ubicacionBox);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            nombre == null ? null : nombre.toLowerCase(),
            ubicacionBox == null ? null : ubicacionBox.toLowerCase()
        );
    }
}
