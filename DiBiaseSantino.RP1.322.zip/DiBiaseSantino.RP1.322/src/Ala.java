package boxformula1;

public class Ala extends Pieza implements Ajustable {
    private int cargaAerodinamica;
    private static final int CARGA_MINIMA = 1;
    private static final int CARGA_MAXIMA = 10;

    public Ala(int cargaAerodinamica, String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) throws CargaAerodinamicaExcedida {
        super(nombre, ubicacionBox, condicionClimatica);
        if (cargaAerodinamica < CARGA_MINIMA || cargaAerodinamica > CARGA_MAXIMA) {
            throw new CargaAerodinamicaExcedida("Carga aerodinamica fuera de rango: " + cargaAerodinamica);
        }
        this.cargaAerodinamica = cargaAerodinamica;
    }

    public int getCargaAerodinamica() {
        return cargaAerodinamica;
    }

    @Override
    public void ajustar() {
        System.out.println("Ajustando ala " + getNombre() + " en " + getUbicacionBox() + " (carga: " + cargaAerodinamica + ")");
    }

    @Override
    public String toString() {
        return "Ala\n" + super.toString() + ", Carga Aerodinamica: " + cargaAerodinamica;
    }
}
