package boxformula1;

public interface Ajustable {
    void ajustar();
}
