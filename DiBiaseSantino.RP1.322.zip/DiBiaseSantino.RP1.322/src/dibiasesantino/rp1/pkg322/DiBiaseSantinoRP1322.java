package boxformula1;

public class BoxFormula1 {

    public static void main(String[] args) {
        RegistroPiezas ingeniero = new RegistroPiezas();

        try {
            Motor m1 = new Motor(100, "PU-016", "Estacion Motor", CondicionClimatica.SECO);
            Motor m2 = new Motor(100, "PU-016", "Estacion Motor", CondicionClimatica.SECO);
            Ala a1 = new Ala(5, "XC-192", "Estacion Ala", CondicionClimatica.MIXTO);
            Neumatico n1 = new Neumatico(Compuesto.HARD, "ZLS-102", "Estacion Neumatico", CondicionClimatica.LLUVIA);

            
            ingeniero.agregarPieza(m1);
            try {
                ingeniero.agregarPieza(m2); 
            } catch (PiezaExistenteException ex) {
                System.out.println("Error al agregar duplicado: " + ex.getMessage());
            }

            
            ingeniero.agregarPieza(a1);
            ingeniero.agregarPieza(n1);

          
            ingeniero.mostrarPiezas();

           
            ingeniero.ajustarPiezas();

          
            ingeniero.buscarPiezasPorCondicion(CondicionClimatica.SECO);
            ingeniero.buscarPiezasPorCondicion(CondicionClimatica.LLUVIA);

        } catch (CargaAerodinamicaExcedida ex) {
            System.out.println("Error al crear Ala: " + ex.getMessage());
        }
    }
}
