package boxformula1;

import java.util.ArrayList;
import java.util.List;

public class RegistroPiezas {
    private List<Pieza> piezas;

    public RegistroPiezas() {
        this.piezas = new ArrayList<>();
    }

    
    public void agregarPieza(Pieza pieza) {
        if (piezas.contains(pieza)) {
            throw new PiezaExistenteException("Esta pieza ya existe con nombre: " + pieza.getNombre() +
                                              " en la ubicacion: " + pieza.getUbicacionBox());
        }
        piezas.add(pieza);
    }

    public void mostrarPiezas() {
        System.out.println("\n=== PIEZAS REGISTRADAS ===");
        for (Pieza p : piezas) {
            System.out.println(p.toString());
        }
    }

    public void ajustarPiezas() {
        System.out.println("\n=== AJUSTANDO PIEZAS ===");
        for (Pieza pieza : piezas) {
            if (pieza instanceof Ajustable) {
                ((Ajustable) pieza).ajustar();
            } else {
                System.out.println("La pieza " + pieza.getNombre() + " en " + pieza.getUbicacionBox() + " no se puede ajustar.");
            }
        }
    }

    public List<Pieza> buscarPiezasPorCondicion(CondicionClimatica condicion) {
        List<Pieza> piezasFiltradas = new ArrayList<>();
        for (Pieza pieza : piezas) {
            if (pieza.getCondicionClimatica() == condicion) {
                piezasFiltradas.add(pieza);
            }
        }
        if (piezasFiltradas.isEmpty()) {
            System.out.println("No se encontraron piezas para la condicion establecida: " + condicion);
        } else {
            System.out.println("=== PIEZAS PARA LA CONDICION: " + condicion + " ===");
            for (Pieza p : piezasFiltradas) {
                System.out.println(p.toString());
            }
        }
        return piezasFiltradas;
    }
}
