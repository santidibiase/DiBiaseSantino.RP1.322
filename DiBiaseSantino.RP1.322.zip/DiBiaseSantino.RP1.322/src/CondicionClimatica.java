package boxformula1;

public enum CondicionClimatica {
    SECO,
    LLUVIA,
    MIXTO;
}
